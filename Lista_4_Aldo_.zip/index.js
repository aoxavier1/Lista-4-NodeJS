const express = require('express');
const app = express();

const path = require('path');
const router = express.Router();
__dirname = path.resolve();


var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));

app.engine('html', require('ejs').renderFile);

app.get('/', (req, res) => {
  res.render(__dirname+'/views/home.html');

})

app.get("/imagem",(req,res)=>{

  res.render(__dirname+'/views/imagem.html');

})
app.get('/calc',function(req,res){ 
var valor = req.body.n1 - req.body.n2;
res.redirect('/calc')
});

app.post('/calc' , function(req,res){
    var valor= req.body.n1 + req.body.n2;
    res.redirect('/')
});

app.get('/login', (req, res) => {
  var user_name="Usuario não identificado";
  res.render(__dirname+'/views/login.html', {user:user_name});
});

app.get('/index2', function(req, res) {
  res.send('Hello World2!')
});

app.post('/login',function(req,res){

  var user_name=req.body.usuario;
  var password=req.body.senha;
  
  console.log("Nome do usuário = "+user_name+", senha é "+password);

  res.render(__dirname+'/views/login.html', {user:user_name});
});

app.listen(process.env.port || 3000);

console.log('Running at Port 3000');
